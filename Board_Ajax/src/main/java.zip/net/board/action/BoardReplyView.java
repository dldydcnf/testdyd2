package net.board.action;

public class BoardReplyView {

}

package net.board.action;

public class BoardModifyAction {

}

package net.member.action;

public class MemberJoinProcessAction2 {

}

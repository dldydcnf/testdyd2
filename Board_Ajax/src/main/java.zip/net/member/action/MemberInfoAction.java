package net.member.action;

public class MemberInfoAction {

}

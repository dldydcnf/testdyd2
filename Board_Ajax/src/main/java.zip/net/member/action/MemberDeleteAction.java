package net.member.action;

public class MemberDeleteAction {

}

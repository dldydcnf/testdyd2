package net.member.action;

public class MemberLisAction {

}

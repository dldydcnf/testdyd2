package net.member.action;

public class MemberLogoutAction {

}

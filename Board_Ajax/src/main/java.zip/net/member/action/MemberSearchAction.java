package net.member.action;

public class MemberSearchAction {

}
